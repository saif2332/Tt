package org.koka.boxclaimer;

import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;

/** Ignores non-web links (e.g. snssdk1233://) so the login page stays visible. */
public class BoxWebClient extends WebViewClient {
    private static boolean web(String u) {
        String l = u == null ? "" : u.toLowerCase();
        return l.startsWith("http://") || l.startsWith("https://")
                || l.startsWith("about:") || l.startsWith("data:")
                || l.startsWith("blob:");
    }

    @Override
    public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
        return !web(r.getUrl().toString());
    }

    @Override
    public boolean shouldOverrideUrlLoading(WebView v, String url) {
        return !web(url);
    }
}
