# -*- coding: utf-8 -*-
import json
import os
import shutil
import sqlite3
import subprocess
import tempfile
import threading
import urllib.request

from kivy.app import App
from kivy.clock import Clock, mainthread
from kivy.core.clipboard import Clipboard
from kivy.core.window import Window
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button
from kivy.uix.image import AsyncImage
from kivy.uix.label import Label
from kivy.uix.scrollview import ScrollView
from kivy.uix.textinput import TextInput
from kivy.utils import platform

from core import Watcher, parse_cookie

UA = ("Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36")

if platform == "android":
    from jnius import autoclass
    from android.runnable import run_on_ui_thread

    PythonActivity = autoclass("org.kivy.android.PythonActivity")
    WebView = autoclass("android.webkit.WebView")
    WebViewClient = autoclass("org.koka.boxclaimer.BoxWebClient")
    CookieManager = autoclass("android.webkit.CookieManager")
    FrameLP = autoclass("android.widget.FrameLayout$LayoutParams")
    _wv = [None]

    @run_on_ui_thread
    def show_webview(height_px):
        act = PythonActivity.mActivity
        wv = WebView(act)
        s = wv.getSettings()
        s.setJavaScriptEnabled(True)
        s.setDomStorageEnabled(True)
        s.setUserAgentString(UA)
        cm = CookieManager.getInstance()
        cm.setAcceptCookie(True)
        cm.setAcceptThirdPartyCookies(wv, True)
        wv.setWebViewClient(WebViewClient())
        act.addContentView(wv, FrameLP(-1, height_px, 48))  # 48 = Gravity.TOP
        wv.loadUrl("https://www.tiktok.com/login")
        _wv[0] = wv

    @run_on_ui_thread
    def hide_webview():
        wv = _wv[0]
        if wv is not None:
            p = wv.getParent()
            if p is not None:
                p.removeView(wv)
            wv.destroy()
            _wv[0] = None

    @run_on_ui_thread
    def keep_awake():
        PythonActivity.mActivity.getWindow().addFlags(128)  # KEEP_SCREEN_ON

    def get_cookie():
        return CookieManager.getInstance().getCookie("https://www.tiktok.com") or ""

    Intent = autoclass("android.content.Intent")
    Uri = autoclass("android.net.Uri")

    def open_tiktok_live(handle):
        """Open the live directly inside the TikTok app."""
        act = PythonActivity.mActivity
        uri = Uri.parse("https://www.tiktok.com/@%s/live" % handle)
        for pkg in ("com.zhiliaoapp.musically", "com.ss.android.ugc.trill", None):
            try:
                it = Intent(Intent.ACTION_VIEW, uri)
                if pkg:
                    it.setPackage(pkg)
                it.addFlags(0x10000000)  # FLAG_ACTIVITY_NEW_TASK
                act.startActivity(it)
                return True
            except Exception:
                continue
        return False
else:
    def show_webview(h): pass
    def hide_webview(): pass
    def keep_awake(): pass
    def get_cookie(): return ""
    def open_tiktok_live(handle): return False


TIKTOK_PKGS = ("com.zhiliaoapp.musically", "com.ss.android.ugc.trill")


def root_fetch_session(tmpdir):
    """Rooted devices only: read this phone's own TikTok app cookie store.
    Returns (cookie_dict, error_text)."""
    def su(cmd, t=25):
        return subprocess.run(["su", "-c", cmd], capture_output=True, text=True,
                              timeout=t)
    try:
        if su("id").returncode != 0:
            return None, "root (su) not granted"
    except Exception as e:
        return None, "su unavailable: %s" % e
    for pkg in TIKTOK_PKGS:
        try:
            found = su("find /data/data/%s -name Cookies -type f 2>/dev/null" % pkg)
        except Exception:
            continue
        for src in found.stdout.split():
            dst = os.path.join(tmpdir, "ck.db")
            su("rm -f '%s' '%s-wal' '%s-journal'; cp '%s' '%s'; "
               "cp '%s-wal' '%s-wal' 2>/dev/null; cp '%s-journal' '%s-journal' 2>/dev/null; "
               "chmod 666 '%s'*" % (dst, dst, dst, src, dst, src, dst, src, dst, dst))
            try:
                db = sqlite3.connect(dst)
                rows = db.execute("select name, value from cookies "
                                  "where host_key like '%tiktok.com'").fetchall()
                db.close()
            except Exception:
                continue
            ck = {n: v for n, v in rows if v}
            if ck.get("sessionid"):
                return ck, ""
    return None, "no sessionid found (log in to the TikTok app first)"


class BoxApp(App):
    title = "Box Claimer"

    def build(self):
        self.dir = self.user_data_dir
        self.sess_path = os.path.join(self.dir, "session.json")
        self.sess = self._load(self.sess_path) or {}
        self.watcher = None
        self.login_open = False
        self.lines = []

        root = BoxLayout(orientation="vertical", padding=10, spacing=8)
        self.status = Label(text="", size_hint_y=None, height=60, font_size="16sp")
        self.profile = BoxLayout(size_hint_y=None, height=0, spacing=12, opacity=0)
        self.avatar = AsyncImage(size_hint=(None, 1), width=110, allow_stretch=True)
        self.uname = Label(text="", font_size="20sp", bold=True, halign="left",
                           valign="middle")
        self.uname.bind(size=lambda w, _: setattr(w, "text_size", w.size))
        self.profile.add_widget(self.avatar)
        self.profile.add_widget(self.uname)
        self.handle = TextInput(hint_text="Live username (without @)", multiline=False,
                                size_hint_y=None, height=90, font_size="18sp",
                                text=self.sess.get("handle", ""))
        sv = ScrollView()
        self.logl = Label(text="", size_hint_y=None, halign="left", valign="top",
                          font_size="13sp")
        self.logl.bind(width=lambda *_: setattr(self.logl, "text_size", (self.logl.width, None)),
                       texture_size=lambda *_: setattr(self.logl, "height", self.logl.texture_size[1]))
        sv.add_widget(self.logl)
        row = BoxLayout(size_hint_y=None, height=110, spacing=8)
        self.btn_login = Button(text="Login with TikTok", font_size="16sp")
        self.btn_go = Button(text="START", font_size="18sp", bold=True)
        self.btn_login.bind(on_release=self.toggle_login)
        self.btn_go.bind(on_release=self.toggle_run)
        row.add_widget(self.btn_login)
        row.add_widget(self.btn_go)
        self.sid_in = TextInput(hint_text="sessionid (or paste cookie)", multiline=False,
                                size_hint=(1, 1), font_size="14sp", password=True)
        btn_paste = Button(text="Paste", size_hint=(None, 1), width=150, font_size="15sp")
        btn_save = Button(text="Save session", size_hint=(None, 1), width=240,
                          font_size="15sp")
        btn_paste.bind(on_release=self.paste_sid)
        btn_save.bind(on_release=self.save_sid)
        btn_root = Button(text="Get session from TikTok app (root)", size_hint_y=None,
                          height=80, font_size="15sp")
        btn_root.bind(on_release=self.root_sid)
        sid_row = BoxLayout(size_hint_y=None, height=80, spacing=8)
        for w in (self.sid_in, btn_paste, btn_save):
            sid_row.add_widget(w)
        for w in (self.status, self.profile, self.handle, btn_root, sid_row, sv, row):
            root.add_widget(w)
        self.refresh_status()
        keep_awake()
        if self.sess.get("sessionid"):
            self.load_profile()
        else:
            # not logged in: show the login screen right away
            Clock.schedule_once(lambda *_: self.toggle_login(), 0.5)
        return root

    # ---------- helpers
    @staticmethod
    def _load(p):
        try:
            with open(p, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            return None

    def _save(self):
        with open(self.sess_path, "w", encoding="utf-8") as f:
            json.dump(self.sess, f)

    def _cfg(self):
        for p in (os.path.join(self.dir, "claim_config.json"),
                  os.path.join(os.path.dirname(os.path.abspath(__file__)),
                               "claim_config.json")):
            c = self._load(p)
            if c is not None:
                c["_dir"] = self.dir
                return c
        return {"_dir": self.dir}

    @mainthread
    def log(self, msg):
        self.lines.append(msg)
        self.lines = self.lines[-150:]
        self.logl.text = "\n".join(self.lines)

    def refresh_status(self):
        ok = bool(self.sess.get("sessionid"))
        self.status.text = "Logged in" if ok else "Not logged in"
        self.status.color = (0.3, 1, 0.4, 1) if ok else (1, 0.4, 0.4, 1)

    # ---------- profile (picture + username)
    def load_profile(self):
        if self.sess.get("username") and self.sess.get("avatar"):
            self.show_profile(self.sess["username"], self.sess["avatar"])
        threading.Thread(target=self._fetch_profile, daemon=True).start()

    def _fetch_profile(self):
        try:
            req = urllib.request.Request(
                "https://www.tiktok.com/passport/web/account/info/?aid=1459",
                headers={"User-Agent": UA, "Referer": "https://www.tiktok.com/",
                         "Cookie": self.sess.get("cookie", "")})
            with urllib.request.urlopen(req, timeout=10) as r:
                d = (json.loads(r.read().decode("utf-8", "replace")) or {}).get("data") or {}
            name = d.get("username") or d.get("screen_name") or ""
            pic = d.get("avatar_url") or d.get("avatar_larger") or ""
            if name:
                self.sess.update(username=name, avatar=pic)
                self._save()
                self.show_profile(name, pic)
        except Exception as e:
            self.log("profile: %s" % e)

    @mainthread
    def show_profile(self, name, pic):
        self.uname.text = "@" + name.lstrip("@")
        if pic:
            self.avatar.source = pic
        self.profile.height = 110
        self.profile.opacity = 1

    # ---------- manual session
    def paste_sid(self, *_):
        try:
            self.sid_in.text = (Clipboard.paste() or "").strip()
        except Exception as e:
            self.log("clipboard: %s" % e)
            return
        self.save_sid()

    def save_sid(self, *_):
        raw = self.sid_in.text.strip().strip('"')
        if not raw:
            self.log("Paste your sessionid first.")
            return
        ck = parse_cookie(raw) if "=" in raw else {}
        sid = ck.get("sessionid") or (raw if "=" not in raw else "")
        if not sid:
            self.log("No sessionid found in the pasted text.")
            return
        self.sess.update(sessionid=sid, idc=ck.get("tt-target-idc", ""),
                         cookie=raw if ck.get("sessionid") else "sessionid=" + sid)
        self._save()
        self.sid_in.text = ""
        if self.login_open:
            self.close_login()
        self.refresh_status()
        self.log("Session saved.")
        self.load_profile()

    def root_sid(self, *_):
        self.log("Reading session from the TikTok app (grant root if asked)...")
        def work():
            d = tempfile.mkdtemp(dir=self.dir)
            try:
                ck, err = root_fetch_session(d)
            finally:
                shutil.rmtree(d, ignore_errors=True)
            self._root_done(ck, err)
        threading.Thread(target=work, daemon=True).start()

    @mainthread
    def _root_done(self, ck, err):
        if not ck:
            self.log("Root fetch failed: %s" % err)
            return
        self.sid_in.text = "; ".join("%s=%s" % kv for kv in ck.items())
        self.save_sid()

    # ---------- login
    def toggle_login(self, *_):
        if self.login_open:
            self.close_login()
            return
        self.login_open = True
        self.btn_login.text = "Close login"
        show_webview(int(Window.height * 0.78))
        self._poll = Clock.schedule_interval(self.check_login, 1.5)

    def close_login(self):
        self.login_open = False
        self.btn_login.text = "Login with TikTok"
        try:
            self._poll.cancel()
        except Exception:
            pass
        hide_webview()

    def check_login(self, *_):
        ck = parse_cookie(get_cookie())
        if ck.get("sessionid"):
            self.sess.update(sessionid=ck["sessionid"],
                             idc=ck.get("tt-target-idc", ""),
                             cookie=get_cookie())
            self._save()
            self.close_login()
            self.refresh_status()
            self.log("Login saved.")
            self.load_profile()

    # ---------- run
    def toggle_run(self, *_):
        if self.watcher:
            self.watcher.stop()
            return
        if not self.sess.get("sessionid"):
            self.log("Login first.")
            return
        h = self.handle.text.strip().lstrip("@")
        if not h:
            self.log("Enter the live username.")
            return
        self.sess["handle"] = h
        self._save()
        self.watcher = Watcher(h, self.sess, self._cfg(), self.log, self._stopped)
        self.btn_go.text = "STOP"
        self.watcher.start()
        self.log("Connecting to @%s ..." % h)
        if not open_tiktok_live(h):
            self.log("Could not open the TikTok app.")

    @mainthread
    def _stopped(self):
        self.watcher = None
        self.btn_go.text = "START"
        self.log("Stopped.")


if __name__ == "__main__":
    BoxApp().run()
